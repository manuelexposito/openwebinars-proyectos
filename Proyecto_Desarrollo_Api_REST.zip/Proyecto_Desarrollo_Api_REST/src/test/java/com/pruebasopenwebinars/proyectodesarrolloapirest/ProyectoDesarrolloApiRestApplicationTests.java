package com.pruebasopenwebinars.proyectodesarrolloapirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoDesarrolloApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
